<?php

function baz() {
}
